scp build/libs/java-multiCameraServer-all.jar pi@frcvision.local:./uploaded.jar
